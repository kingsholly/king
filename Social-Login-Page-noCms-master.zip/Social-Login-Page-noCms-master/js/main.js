"use strict"
//  let $userName= document.getElementById("username");
//  let $passWord = document.getElementById("password");
//  let $submitUser = document.getElementById("submit");
//  let $noAtSignErrorMessage = document.getElementById("error")
//  let $atPlaceHolder = $userName.value.indexOf("@");

//     function usernameFormat(event){
//             if($atPlaceHolder <= -1){
//                 $noAtSignErrorMessage.innerHTML="<h1>User Name Begin With The @ sign!</h1>";
//                 $noAtSignErrorMessage.style.visibility ="visible";
//                 $noAtSignErrorMessage.style.fontSize="70%";
//                return event.preventDefault();
//             } 
//     }
                
//     $submitUser.addEventListener("click",usernameFormat);
// there is no javascript that controls the page, commented syntax need help