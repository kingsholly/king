#Social Login Template
    #First Phased all Bugs Fixed or rather commented out,
    ;Needs Help..